package GUI;
import javax.swing.JFrame;

import maze.Maze;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 * In this window, the user-defined Maze is created and then solved by the user.
 * @author Erick
 *
 */
public class MazeGeneratorGUI extends JFrame{
	boolean start, solving;

	/**
	 * Create the application.
	 */
	public MazeGeneratorGUI(Maze m) {	
		initialize(m);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(Maze m) {
		this.setBounds(15, 15, 645, 715);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(null);
		
		Maze maze = m;
		maze.setBounds(10, 32, 600, 600);
		this.getContentPane().add(maze);
		
		
		JButton btnStop = new JButton("Start");	
		btnStop.addKeyListener(maze);
		btnStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				start = !start;
				solving = maze.mazeDone() && maze.getRunner().isDone() && !start;
				maze.getRunner().setDone(false);
				String label = !start ? (!maze.mazeDone() ?"Start": "Solve"):"Pause";
				btnStop.setText(label);
				
				new Thread(){
					public void run()
					{
						while(!maze.mazeDone() && start)
						{
							
							maze.update();				//==========================================
							maze.repaint();				// This section of code allows the graphics to
							maze.delay(40);				// go a little faster...											
							if(maze.mazeDone()){
								start = false;
								btnStop.setText("Solve");
							}
						}
						
						
						while(!maze.getRunner().isDone() && start)
						{
							maze.update();
							maze.repaint();
							maze.delay(40);
							if(maze.getRunner().isDone()){
								btnStop.setText("Solve");
								solving = true;
							}
						}
						
						while(solving && start)
						{
							maze.update();
							maze.repaint();
							maze.delay(40);
							if(maze.getRunner().getCurrent().end()){
								maze.update();
								maze.repaint();
								solving = false;
								start = false;
								JOptionPane.showMessageDialog(null, "You solved the Maze!", "Maze Solved", JOptionPane.INFORMATION_MESSAGE);
								
							}
						}	
					}
				}.start();
				}
		});		
	
		btnStop.setBounds(54, 643, 89, 23);
		this.getContentPane().add(btnStop);
		
		JButton btnStep = new JButton("Step");
		btnStep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				maze.update();
				maze.repaint();
			}
		});
		btnStep.setBounds(197, 643, 89, 23);
		this.getContentPane().add(btnStep);
		
		JButton btnExit = new JButton("Calculate");
		btnExit.addKeyListener(maze);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				start = false;
				if(!maze.mazeDone())
				{
					do{
						maze.update();
					}while(!maze.mazeDone());
					btnStop.setText("Solve");
				}						
				else
					if(!maze.getRunner().isDone())
					{
						do maze.update();
						while(!maze.getRunner().isDone());
						solving = true;						
					}
				
				new Thread(){
					public void run()
					{
						while(solving)
						{
							maze.update();
							maze.repaint();
							maze.delay(40);
							if(maze.getRunner().getCurrent().end()){
								maze.update();
								maze.reset();
								solving = false;
								JOptionPane.showMessageDialog(null, "You solved the Maze!", "Maze Solved", JOptionPane.INFORMATION_MESSAGE);
								
							}
						}	
					}
				}.start();
				
				maze.repaint();
			}
		});
		btnExit.setBounds(483, 643, 89, 23);
		this.getContentPane().add(btnExit);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				start = false;
				solving = false;
				maze.reset();
				maze.repaint();
			}
		});
		btnReset.setBounds(340, 643, 89, 23);
		this.getContentPane().add(btnReset);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 97, 21);
		this.getContentPane().add(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmBackToSettings = new JMenuItem("Back to Settings");
		mntmBackToSettings.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				MazeSettingsGUI settings = new MazeSettingsGUI();
				settings.setVisible(true);
			}
		});
		mnNewMenu.add(mntmBackToSettings);
		
		JMenuItem mntmOpenMaze = new JMenuItem("Import Maze");
		mnNewMenu.add(mntmOpenMaze);
		
		JMenuItem mntmSaveMaze = new JMenuItem("Save Maze");
		mnNewMenu.add(mntmSaveMaze);
	}
}
